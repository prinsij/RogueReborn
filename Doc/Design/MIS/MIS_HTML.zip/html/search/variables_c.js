var searchData=
[
  ['type',['type',['../classItem.html#a22a98aed7ce8f0314b597a5739c415b7',1,'Item']]]
];
