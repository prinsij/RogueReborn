var searchData=
[
  ['context',['Context',['../classItem.html#ab6dfcf8b380c9db3c7809b2b41cc55a8',1,'Item']]]
];
