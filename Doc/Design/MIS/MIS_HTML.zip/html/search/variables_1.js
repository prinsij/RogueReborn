var searchData=
[
  ['canstack',['canStack',['../classItem.html#a004410a62ed55a5d8e5bf6e60793a4b7',1,'Item']]],
  ['canthrow',['canThrow',['../classItem.html#ab3ae0f9fb675f526b2e0e670ed710532',1,'Item']]],
  ['character',['character',['../classTerrain.html#a7755fdfc81db55f686796c689f7a57eb',1,'Terrain']]],
  ['checked',['checked',['../classTerrain.html#ad39c3f909d269a9ef286b6c688460070',1,'Terrain']]],
  ['classname',['className',['../classItem.html#a4f4f6d1c43ce210d697307e2a20abe52',1,'Item']]],
  ['context',['context',['../classItem.html#aebb6ac5cc2e48c97367c8e184f751f73',1,'Item']]],
  ['currenthp',['currentHP',['../classMob.html#a0d03a29a03bdd48b402d78ff0ee16228',1,'Mob']]]
];
