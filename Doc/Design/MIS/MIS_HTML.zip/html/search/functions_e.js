var searchData=
[
  ['quaff',['quaff',['../classPlayerChar.html#a55457494bd881b6a19ea50ab47599743',1,'PlayerChar']]]
];
