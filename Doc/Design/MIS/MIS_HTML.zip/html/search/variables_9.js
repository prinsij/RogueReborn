var searchData=
[
  ['parent',['parent',['../classTerrain.html#afa281d447bf7742b37f4ca2285b2f6aa',1,'Terrain']]],
  ['player',['player',['../classPlayState.html#acb34ecb513a90cb1abed0d21164ef866',1,'PlayState']]],
  ['pseudoname',['pseudoName',['../classItem.html#a1678c5e866013b749c793ab9f6c3d9fd',1,'Item']]]
];
