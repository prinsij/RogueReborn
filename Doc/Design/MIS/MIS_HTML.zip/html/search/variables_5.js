var searchData=
[
  ['identified',['identified',['../classItem.html#aca6039d4b42c5c62ad59559166b3f778',1,'Item']]],
  ['ignoretransitions',['ignoreTransitions',['../classScroll.html#a9c9b23ae7ddf7abadfc398d76123737d',1,'Scroll']]]
];
