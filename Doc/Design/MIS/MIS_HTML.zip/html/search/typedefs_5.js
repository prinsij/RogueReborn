var searchData=
[
  ['wand_5ftuple_5ftype',['WAND_TUPLE_TYPE',['../wand_8h.html#a9d5b5bf74fd19d3316b52cd8746323f4',1,'wand.h']]],
  ['weapon_5ftuple_5ftype',['WEAPON_TUPLE_TYPE',['../weapon_8h.html#a5f3c87f300d90824e1834873a19d117e',1,'weapon.h']]]
];
