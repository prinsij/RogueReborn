var searchData=
[
  ['quickdrop',['QuickDrop',['../classQuickDrop.html',1,'']]],
  ['quickeat',['QuickEat',['../classQuickEat.html',1,'']]],
  ['quickthrow',['QuickThrow',['../classQuickThrow.html',1,'']]],
  ['quitprompt2',['QuitPrompt2',['../classQuitPrompt2.html',1,'']]]
];
