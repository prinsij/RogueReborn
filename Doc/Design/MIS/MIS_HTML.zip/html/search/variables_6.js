var searchData=
[
  ['maxhp',['maxHP',['../classMob.html#acfc48942594e60e22eb3e46b257ef2ec',1,'Mob']]]
];
