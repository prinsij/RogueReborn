var searchData=
[
  ['updatehealthregen',['updateHealthRegen',['../classPlayerChar.html#a329713652bfb6c319556454950434563',1,'PlayerChar']]]
];
