var searchData=
[
  ['visible',['visible',['../classFeature.html#a1d5823c3830c051ccb9bf51b5b4fad43',1,'Feature::visible()'],['../classTerrain.html#ab91b93be2fb3c812ee2f1225be007c9e',1,'Terrain::visible()']]]
];
