var searchData=
[
  ['scroll_5ftuple_5ftype',['SCROLL_TUPLE_TYPE',['../scroll_8h.html#aa3ed33a30a19b94da6b3ad32e0a678ca',1,'scroll.h']]]
];
