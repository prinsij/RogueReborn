var searchData=
[
  ['name',['name',['../classItem.html#a342b7a351c9ae1c5430aa3ef65b670bd',1,'Item::name()'],['../classMob.html#a653a8a18addedf7d9533ee670628d2a9',1,'Mob::name()']]]
];
