var searchData=
[
  ['fcolor',['fcolor',['../classFeature.html#aa923d27865a1b3295fcaee705e2a7414',1,'Feature::fcolor()'],['../classMob.html#a981920ba1fffdf4fdcb8ff71a36f277b',1,'Mob::fcolor()']]]
];
